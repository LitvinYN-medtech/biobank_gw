from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from core.database import CurrentAsyncSession
from depends import verify_bearer
from models.bims import BIMSDeviceRegistry, ServerCryoAliquot, ServerVacuumSession
from schemas.sync import SyncAliquotsRequest, SyncAliquotsResponse

router = APIRouter(prefix="/api/v1", tags=["sync"], dependencies=[Depends(verify_bearer)])


@router.post(
    "/sync/aliquots",
    response_model=SyncAliquotsResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Batch aliquot synchronisation",
    description=(
        "Accepts a JSON batch of aliquot scan logs from the TSD device and persists them "
        "in a single PostgreSQL transaction. Any failure causes a full ROLLBACK — partial "
        "writes are not possible.\n\n"
        "The endpoint is **fully idempotent**: re-sending the same `session_id` / `aliquot_id` "
        "combination is safe and will not create duplicate rows."
    ),
    responses={
        201: {
            "description": "Batch accepted",
            "content": {
                "application/json": {
                    "example": {"session_id": "SESSION-2026-001", "accepted": 6}
                }
            },
        },
        401: {"description": "Missing or invalid Bearer token"},
        403: {"description": "Device serial not registered or device is inactive"},
        422: {"description": "Validation error in request body"},
    },
)
async def sync_aliquots(
    payload: SyncAliquotsRequest,
    session: CurrentAsyncSession,
) -> SyncAliquotsResponse:
    async with session.begin():
        result = await session.execute(
            select(BIMSDeviceRegistry).where(
                BIMSDeviceRegistry.device_serial == payload.device_serial,
                BIMSDeviceRegistry.is_active.is_(True),
            )
        )
        device = result.scalars().first()
        if device is None:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Unknown or inactive device")

        await session.execute(
            pg_insert(ServerVacuumSession)
            .values(
                session_id=payload.session_id,
                device_id=device.id,
                session_date=payload.session_date,
            )
            .on_conflict_do_nothing(index_elements=["session_id"])
        )
        await session.flush()

        for item in payload.aliquots:
            await session.execute(
                pg_insert(ServerCryoAliquot)
                .values(
                    session_id=payload.session_id,
                    aliquot_id=item.aliquot_id,
                    tube_type=item.tube_type,
                    barcode=item.barcode,
                    position=item.position,
                    status=item.status,
                    scanned_at=item.scanned_at,
                    lis_ancestry_payload=item.lis_ancestry_payload,
                    consent_digital_payload=item.consent_digital_payload,
                )
                .on_conflict_do_nothing(constraint="uq_cryo_aliquot_session_aliquot")
            )

    return SyncAliquotsResponse(session_id=payload.session_id, accepted=len(payload.aliquots))
