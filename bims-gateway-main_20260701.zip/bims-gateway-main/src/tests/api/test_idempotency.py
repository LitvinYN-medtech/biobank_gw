"""Idempotency tests: double-send of the same payload must not create duplicates."""

import pytest
from httpx import AsyncClient, ASGITransport
from sqlalchemy import func, select

from app import app
from core.database import async_session_maker
from models.bims import ServerCryoAliquot

AUTH = {"Authorization": "Bearer mgt_bims_mvp_2026_token"}

PAYLOAD = {
    "session_id": "SESSION-IDEM-001",
    "session_date": "2026-06-15T09:00:00Z",
    "device_serial": "TSD-TEST-001",
    "aliquots": [
        {"aliquot_id": "IDEM-ALQ-001", "tube_type": "EDTA", "barcode": "IDEM-BC001"},
        {"aliquot_id": "IDEM-ALQ-002", "tube_type": "SST",  "barcode": "IDEM-BC002"},
    ],
}


@pytest.mark.asyncio
async def test_double_send_no_duplicates():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        r1 = await ac.post("/api/v1/sync/aliquots", json=PAYLOAD, headers=AUTH)
        r2 = await ac.post("/api/v1/sync/aliquots", json=PAYLOAD, headers=AUTH)

    assert r1.status_code == 201
    assert r2.status_code == 201  # idempotent — no error on second send

    async with async_session_maker() as db:
        result = await db.execute(
            select(func.count()).where(ServerCryoAliquot.session_id == PAYLOAD["session_id"])
        )
        count = result.scalar_one()

    assert count == 2, f"Expected 2 aliquots, got {count} — duplicates were inserted"
