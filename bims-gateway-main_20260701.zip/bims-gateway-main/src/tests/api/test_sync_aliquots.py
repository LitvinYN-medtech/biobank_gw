"""Contract + rollback tests for POST /api/v1/sync/aliquots."""

import pytest
from httpx import AsyncClient, ASGITransport

from app import app

AUTH = {"Authorization": "Bearer mgt_bims_mvp_2026_token"}
VALID_DEVICE = "TSD-TEST-001"

PAYLOAD = {
    "session_id": "SESSION-TEST-001",
    "session_date": "2026-06-15T08:00:00Z",
    "device_serial": VALID_DEVICE,
    "aliquots": [
        {"aliquot_id": "ALQ-001", "tube_type": "EDTA", "barcode": "BC001", "position": 1, "status": "ok"},
        {"aliquot_id": "ALQ-002", "tube_type": "SST",  "barcode": "BC002", "position": 2, "status": "ok"},
    ],
}


@pytest.mark.asyncio
async def test_sync_201_created():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/sync/aliquots", json=PAYLOAD, headers=AUTH)
    assert resp.status_code == 201
    data = resp.json()
    assert data["session_id"] == PAYLOAD["session_id"]
    assert data["accepted"] == 2


@pytest.mark.asyncio
async def test_sync_unknown_device_403():
    payload = {**PAYLOAD, "session_id": "SESSION-UNKNOWN", "device_serial": "UNKNOWN-DEVICE"}
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/sync/aliquots", json=payload, headers=AUTH)
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_sync_401_no_token():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/sync/aliquots", json=PAYLOAD)
    assert resp.status_code == 403
