from datetime import datetime

from pydantic import BaseModel


class AliquotItem(BaseModel):
    aliquot_id: str
    tube_type: str | None = None
    barcode: str | None = None
    position: int | None = None
    status: str | None = None
    scanned_at: datetime | None = None
    lis_ancestry_payload: dict | None = None
    consent_digital_payload: dict | None = None


class SyncAliquotsRequest(BaseModel):
    session_id: str
    session_date: datetime
    device_serial: str
    aliquots: list[AliquotItem]


class SyncAliquotsResponse(BaseModel):
    session_id: str
    accepted: int
