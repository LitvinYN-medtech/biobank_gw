from pydantic import BaseModel


class DeviceConfigResponse(BaseModel):
    clinic_code: str
    lab_code: str
    barcode_regex_pattern: str
    aliquots_in_set_count: int
    allowed_tubes: list
