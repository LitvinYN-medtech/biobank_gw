"""Seed script: populates reference tables with test data (idempotent)."""

import asyncio

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from configs import get_settings
from models.bims import BIMSDeviceRegistry, DictClinic, DictLabsConfig

settings = get_settings()


async def seed() -> None:
    engine = create_async_engine(settings.pg_url)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async with session_factory() as session:
        async with session.begin():
            # 1. Clinic
            await session.execute(
                pg_insert(DictClinic)
                .values(clinic_code="CLINIC_TEST_01", clinic_name="Тестовая клиника №1")
                .on_conflict_do_nothing(index_elements=["clinic_code"])
            )
            await session.flush()

            clinic_id = (
                await session.execute(
                    select(DictClinic.id).where(DictClinic.clinic_code == "CLINIC_TEST_01")
                )
            ).scalar_one()

            # 2. Lab config
            await session.execute(
                pg_insert(DictLabsConfig)
                .values(
                    clinic_id=clinic_id,
                    lab_code="LAB_01",
                    barcode_regex_pattern=r"^[A-Z0-9]{10,14}$",
                    aliquots_in_set_count=6,
                    allowed_tubes=["EDTA", "SST", "Citrate"],
                )
                .on_conflict_do_nothing(constraint="uq_labs_config_clinic_lab")
            )
            await session.flush()

            labs_config_id = (
                await session.execute(
                    select(DictLabsConfig.id).where(
                        DictLabsConfig.clinic_id == clinic_id,
                        DictLabsConfig.lab_code == "LAB_01",
                    )
                )
            ).scalar_one()

            # 3. Test TSD device
            await session.execute(
                pg_insert(BIMSDeviceRegistry)
                .values(
                    device_serial="TSD-TEST-001",
                    clinic_id=clinic_id,
                    labs_config_id=labs_config_id,
                )
                .on_conflict_do_nothing(index_elements=["device_serial"])
            )

    print("Seed completed.")
    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(seed())
