from fastapi import APIRouter, Depends, status
from sqlalchemy.dialects.postgresql import insert as pg_insert

from core.database import CurrentAsyncSession
from depends import verify_bearer
from models.bims import AuditTrailEvent
from schemas.audit import AuditBatchRequest, AuditBatchResponse

router = APIRouter(
    prefix="/api/v1", tags=["audit"], dependencies=[Depends(verify_bearer)]
)


@router.post(
    "/audit/events",
    response_model=AuditBatchResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Batch audit event ingestion",
    description=(
        "Accepts a JSON batch of audit events from a TSD device and persists them in a single "
        "PostgreSQL transaction. Any failure causes a full ROLLBACK — partial writes are not possible.\n\n"
        "**Idempotency**: re-sending an event with the same `event_id` is safe and will not create duplicates.\n\n"
        "**ФЗ-152**: `patient_hash`, when provided, must be a lowercase 64-hex SHA-256 digest. "
        "Plain patient identifiers are rejected with HTTP 422."
    ),
    responses={
        201: {"description": "Batch accepted"},
        401: {"description": "Missing or invalid Bearer token"},
        422: {
            "description": "Validation error — including invalid patient_hash format"
        },
    },
)
async def ingest_audit_events(
    payload: AuditBatchRequest,
    session: CurrentAsyncSession,
) -> AuditBatchResponse:
    async with session.begin():
        for event in payload.events:
            event_payload = event.payload or {}
            await session.execute(
                pg_insert(AuditTrailEvent)
                .values(
                    event_id=event.event_id,
                    device_serial=payload.device_serial,
                    patient_hash=event.patient_hash,
                    event_type=event.event_type,
                    payload=event.payload,
                    occurred_at=event.occurred_at,
                    clinic_code=event_payload.get("clinic_code"),
                    lab_code=event_payload.get("lab_code"),
                    session_id=event_payload.get("session_id"),
                    vacuum_barcode_raw=event_payload.get("vacuum_barcode"),
                    cryo_barcode=event_payload.get("barcode"),
                    container_id=event_payload.get("container_barcode"),
                    sync_result=_sync_result(event.event_type),
                    error_details=event_payload.get("reason"),
                )
                .on_conflict_do_nothing(index_elements=["event_id"])
            )

    return AuditBatchResponse(accepted=len(payload.events))


def _sync_result(event_type: str) -> str | None:
    if event_type == "SYNC_SUCCESS":
        return "SUCCESS"
    if event_type == "SYNC_FAILURE":
        return "FAILURE"
    return None
