from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from core.database import CurrentAsyncSession
from depends import verify_bearer
from models.bims import (
    BIMSDeviceRegistry,
    ServerCryoAliquot,
    ServerShippedContainersLog,
    ServerVacuumSession,
)
from schemas.sync import (
    SyncAliquotsRequest,
    SyncAliquotsResponse,
    SyncContainersRequest,
    SyncContainersResponse,
)

router = APIRouter(prefix="/api/v1", tags=["sync"], dependencies=[Depends(verify_bearer)])


@router.post(
    "/sync/aliquots",
    response_model=SyncAliquotsResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Batch aliquot synchronisation",
    description=(
        "Accepts a JSON batch of aliquot scan logs from the TSD device and persists them "
        "in a single PostgreSQL transaction. Any failure causes a full ROLLBACK — partial "
        "writes are not possible.\n\n"
        "The endpoint is **fully idempotent**: re-sending the same `session_id` / `aliquot_id` "
        "combination is safe and will not create duplicate rows."
    ),
    responses={
        201: {
            "description": "Batch accepted",
            "content": {
                "application/json": {
                    "example": {"session_id": "SESSION-2026-001", "accepted": 6}
                }
            },
        },
        401: {"description": "Missing or invalid Bearer token"},
        403: {"description": "Device serial not registered or device is inactive"},
        422: {"description": "Validation error in request body"},
    },
)
async def sync_aliquots(
    payload: SyncAliquotsRequest,
    session: CurrentAsyncSession,
) -> SyncAliquotsResponse:
    async with session.begin():
        result = await session.execute(
            select(BIMSDeviceRegistry).where(
                BIMSDeviceRegistry.device_serial == payload.device_serial,
                BIMSDeviceRegistry.is_active.is_(True),
            )
        )
        device = result.scalars().first()
        if device is None:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Unknown or inactive device")

        await session.execute(
            pg_insert(ServerVacuumSession)
            .values(
                session_id=payload.session_id,
                device_id=device.id,
                session_date=payload.session_date,
                vacuum_barcode_raw=payload.vacuum_barcode_raw,
                patient_metadata_jsonb=(
                    payload.patient_metadata.model_dump() if payload.patient_metadata else None
                ),
            )
            .on_conflict_do_nothing(index_elements=["session_id"])
        )
        await session.flush()

        for item in payload.aliquots:
            await session.execute(
                pg_insert(ServerCryoAliquot)
                .values(
                    session_id=payload.session_id,
                    aliquot_id=item.aliquot_id,
                    barcode=item.barcode,
                    position=item.position,
                    status=item.status,
                    scanned_at=item.scanned_at,
                    lis_ancestry_payload=item.lis_ancestry_payload,
                    consent_digital_payload=item.consent_digital_payload,
                )
                .on_conflict_do_nothing(constraint="uq_cryo_aliquot_session_aliquot")
            )

    return SyncAliquotsResponse(session_id=payload.session_id, accepted=len(payload.aliquots))


@router.post(
    "/sync/containers",
    response_model=SyncContainersResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Container handover synchronisation",
    description=(
        "Persists tablet/container handover events from the TSD device. "
        "Each `session_id` must already exist in `server_vacuum_sessions` for the device. "
        "Re-sending the same `session_id` + `container_barcode` pair is idempotent."
    ),
    responses={
        201: {"description": "Handover accepted"},
        401: {"description": "Missing or invalid Bearer token"},
        403: {"description": "Device serial not registered or device is inactive"},
        422: {"description": "Validation error in request body"},
    },
)
async def sync_containers(
    payload: SyncContainersRequest,
    session: CurrentAsyncSession,
) -> SyncContainersResponse:
    container_barcode = payload.container_barcode.strip().upper()

    async with session.begin():
        device = await _get_active_device(session, payload.device_serial)
        if device is None:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Unknown or inactive device")

        if payload.session_ids:
            target_session_ids = payload.session_ids
        else:
            target_session_ids = await _unshipped_session_ids_for_device(session, device.id)

        accepted = False
        for session_id in target_session_ids:
            if not await _session_belongs_to_device(session, session_id, device.id):
                continue

            existing = await session.execute(
                select(ServerShippedContainersLog.id).where(
                    ServerShippedContainersLog.session_id == session_id,
                    ServerShippedContainersLog.container_barcode == container_barcode,
                )
            )
            if existing.scalar_one_or_none() is not None:
                accepted = True
                continue

            await session.execute(
                pg_insert(ServerShippedContainersLog).values(
                    session_id=session_id,
                    container_barcode=container_barcode,
                    shipped_at=payload.shipped_at,
                )
            )
            accepted = True

    return SyncContainersResponse(container_barcode=container_barcode, accepted=accepted)


async def _get_active_device(session: CurrentAsyncSession, device_serial: str) -> BIMSDeviceRegistry | None:
    result = await session.execute(
        select(BIMSDeviceRegistry).where(
            BIMSDeviceRegistry.device_serial == device_serial,
            BIMSDeviceRegistry.is_active.is_(True),
        )
    )
    return result.scalars().first()


async def _session_belongs_to_device(
    session: CurrentAsyncSession,
    session_id: str,
    device_id: int,
) -> bool:
    result = await session.execute(
        select(ServerVacuumSession.session_id).where(
            ServerVacuumSession.session_id == session_id,
            ServerVacuumSession.device_id == device_id,
        )
    )
    return result.scalar_one_or_none() is not None


async def _unshipped_session_ids_for_device(session: CurrentAsyncSession, device_id: int) -> list[str]:
    shipped_subq = select(ServerShippedContainersLog.session_id)
    result = await session.execute(
        select(ServerVacuumSession.session_id).where(
            ServerVacuumSession.device_id == device_id,
            ServerVacuumSession.session_id.not_in(shipped_subq),
        )
    )
    return list(result.scalars().all())
