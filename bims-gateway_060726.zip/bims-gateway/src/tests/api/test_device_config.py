"""Contract tests for GET /api/v1/device/config — runs against a real DB (pytest-asyncio)."""

import pytest
from httpx import AsyncClient, ASGITransport

from app import app

AUTH = {"Authorization": "Bearer mgt_bims_mvp_2026_token"}
VALID_SERIAL = "TSD-TEST-001"
UNKNOWN_SERIAL = "UNKNOWN-999"


@pytest.mark.asyncio
async def test_config_200_known_device():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.get("/api/v1/device/config", headers={**AUTH, "X-Device-Serial": VALID_SERIAL})
    assert resp.status_code == 200
    data = resp.json()
    assert "barcode_regex_pattern" in data
    assert "aliquots_in_set_count" in data
    assert "patient_hash_salt" in data
    assert "cryo_barcode_regex_pattern" in data


@pytest.mark.asyncio
async def test_config_403_unknown_device():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.get("/api/v1/device/config", headers={**AUTH, "X-Device-Serial": UNKNOWN_SERIAL})
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_config_401_no_token():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.get("/api/v1/device/config", headers={"X-Device-Serial": VALID_SERIAL})
    assert resp.status_code == 403  # HTTPBearer returns 403 when header missing
