import re

from pydantic import BaseModel, field_validator

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class PatientMetadata(BaseModel):
    patient_id_hash: str
    sex: str
    age: int

    @field_validator("patient_id_hash")
    @classmethod
    def validate_patient_hash(cls, value: str) -> str:
        if not _SHA256_RE.match(value):
            raise ValueError(
                "patient_id_hash must be a lowercase 64-hex SHA-256 digest (ФЗ-152)"
            )
        return value

    @field_validator("sex")
    @classmethod
    def validate_sex(cls, value: str) -> str:
        if value not in {"M", "F"}:
            raise ValueError("sex must be M or F")
        return value

    @field_validator("age")
    @classmethod
    def validate_age(cls, value: int) -> int:
        if value < 0:
            raise ValueError("age must be non-negative")
        return value
