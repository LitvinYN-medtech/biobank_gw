from pydantic import BaseModel


class DeviceConfigResponse(BaseModel):
    clinic_code: str
    lab_code: str
    barcode_regex_pattern: str
    cryo_barcode_regex_pattern: str | None = None
    patient_hash_salt: str
    aliquots_in_set_count: int
    allowed_tubes: list
