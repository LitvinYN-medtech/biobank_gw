import re
from datetime import datetime

from pydantic import BaseModel, field_validator

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class AuditEvent(BaseModel):
    event_id: str
    event_type: str
    occurred_at: datetime
    patient_hash: str | None = None
    payload: dict | None = None

    @field_validator("patient_hash")
    @classmethod
    def validate_patient_hash(cls, v: str | None) -> str | None:
        if v is not None and not _SHA256_RE.match(v):
            raise ValueError(
                "patient_hash must be a lowercase 64-hex SHA-256 digest (ФЗ-152)"
            )
        return v


class AuditBatchRequest(BaseModel):
    device_serial: str
    events: list[AuditEvent]


class AuditBatchResponse(BaseModel):
    accepted: int
