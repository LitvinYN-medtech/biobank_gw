from datetime import datetime

from pydantic import BaseModel, Field

from schemas.patient_metadata import PatientMetadata


class AliquotItem(BaseModel):
    aliquot_id: str
    barcode: str | None = None
    position: int | None = None
    status: str | None = None
    scanned_at: datetime | None = None
    lis_ancestry_payload: dict | None = None
    consent_digital_payload: dict | None = None


class SyncAliquotsRequest(BaseModel):
    session_id: str
    session_date: datetime
    device_serial: str
    aliquots: list[AliquotItem]
    vacuum_barcode_raw: str | None = None
    patient_metadata: PatientMetadata | None = Field(default=None, alias="patient_metadata_jsonb")

    model_config = {"populate_by_name": True}


class SyncAliquotsResponse(BaseModel):
    session_id: str
    accepted: int


class SyncContainersRequest(BaseModel):
    device_serial: str
    container_barcode: str
    shipped_at: datetime
    session_ids: list[str] = []


class SyncContainersResponse(BaseModel):
    container_barcode: str
    accepted: bool
