"""Export the OpenAPI schema to docs/openapi.json."""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app import app

schema = app.openapi()
out = Path(__file__).parents[1] / "docs" / "openapi.json"
out.write_text(json.dumps(schema, ensure_ascii=False, indent=2))
print(f"OpenAPI schema written to {out}")
