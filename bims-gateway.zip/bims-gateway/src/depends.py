from fastapi import HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from configs import get_settings

_bearer = HTTPBearer(auto_error=True)


def verify_bearer(
    credentials: HTTPAuthorizationCredentials = Security(_bearer),
) -> None:
    settings = get_settings()
    if credentials.credentials != settings.BEARER_TOKEN:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing bearer token")
