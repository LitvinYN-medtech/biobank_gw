"""Structured gateway error responses for sync and audit endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import HTTPException, Request, status
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError


def postgres_error_details(exc: SQLAlchemyError) -> dict[str, Any]:
    """Extract PostgreSQL diagnostics from a SQLAlchemy error."""
    orig = getattr(exc, "orig", None)
    if orig is None:
        return {"reason": str(exc)}

    details: dict[str, Any] = {
        "postgres_code": getattr(orig, "sqlstate", None),
        "postgres_message": getattr(orig, "diag", None) and orig.diag.message_primary or str(orig),
    }
    if diag := getattr(orig, "diag", None):
        if diag.message_detail:
            details["postgres_detail"] = diag.message_detail
        if diag.constraint_name:
            details["postgres_constraint"] = diag.constraint_name
        if diag.table_name:
            details["postgres_table"] = diag.table_name
        if diag.column_name:
            details["postgres_column"] = diag.column_name
    return details


def gateway_error_body(
    message: str,
    *,
    status_code: int,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"message": message, "http_status": status_code}
    if extra:
        body.update(extra)
    return body


async def sqlalchemy_error_handler(_request: Request, exc: SQLAlchemyError) -> JSONResponse:
    details = postgres_error_details(exc)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=gateway_error_body(
            "Database transaction failed and was rolled back",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            extra=details,
        ),
    )


async def http_exception_handler(_request: Request, exc: HTTPException) -> JSONResponse:
    detail = exc.detail
    if isinstance(detail, str):
        body = gateway_error_body(detail, status_code=exc.status_code)
    elif isinstance(detail, dict):
        message = detail.get("message")
        if not isinstance(message, str):
            message = "Request failed"
        body = gateway_error_body(message, status_code=exc.status_code, extra=detail)
    else:
        body = gateway_error_body(str(detail), status_code=exc.status_code, extra={"detail": detail})
    return JSONResponse(status_code=exc.status_code, content=body)
