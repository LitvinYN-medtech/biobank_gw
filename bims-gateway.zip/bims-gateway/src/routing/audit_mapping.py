"""Map incoming audit events to audit_trail_events columns."""

from __future__ import annotations

from schemas.audit import AuditEvent


def resolve_session_id(event: AuditEvent) -> str | None:
    payload = event.payload or {}
    if event.session_id:
        return event.session_id
    if payload.get("session_id"):
        return str(payload["session_id"])
    entity_type = payload.get("entity_type")
    entity_id = payload.get("entity_id")
    if entity_type == "aliquots" and entity_id:
        return str(entity_id)
    session_ids = payload.get("session_ids")
    if isinstance(session_ids, list) and session_ids:
        return str(session_ids[0])
    return None


def resolve_container_id(payload: dict) -> str | None:
    """Только явный ШК планшета из ship-событий.

    Для SYNC_SUCCESS/FAILURE `entity_id` не маппим в container_id —
    иначе туда попадает session_id / barcode вместо чистого ШК, а
    session_id и sync_result должны жить в своих колонках.
    """
    if container := payload.get("container_barcode"):
        return str(container)
    return None


def resolve_sync_result(event_type: str, payload: dict) -> str | None:
    raw = payload.get("sync_result")
    if isinstance(raw, str):
        normalized = raw.strip().lower()
        if normalized == "success":
            return "SUCCESS"
        if normalized == "failure":
            return "FAILURE"
        upper = raw.strip().upper()
        if upper in {"SUCCESS", "FAILURE"}:
            return upper
    if event_type == "SYNC_SUCCESS":
        return "SUCCESS"
    if event_type == "SYNC_FAILURE":
        return "FAILURE"
    return None


def resolve_error_details(payload: dict) -> str | None:
    parts: list[str] = []
    if reason := payload.get("reason"):
        parts.append(str(reason))
    if api_path := payload.get("api_path"):
        parts.append(f"api_path: {api_path}")
    if status := payload.get("http_status"):
        parts.append(f"http_status: {status}")
    if msg := payload.get("gateway_message"):
        parts.append(f"gateway_message: {msg}")
    if body := payload.get("gateway_response_body"):
        parts.append(f"gateway_response_body: {body}")
    return "\n".join(parts) if parts else None
