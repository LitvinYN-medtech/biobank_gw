"""Device access helpers for sync and config endpoints."""

from fastapi import HTTPException, status

from models.bims import BIMSDeviceRegistry


def ensure_device_operational(device: BIMSDeviceRegistry | None) -> BIMSDeviceRegistry:
    if device is None or not device.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Device not found or inactive")

    if not device.clinic.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Clinic profile is inactive",
        )

    if not device.labs_config.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Laboratory profile is inactive",
        )

    return device
