from fastapi import APIRouter
from sqlalchemy import text

from core.database import async_session_maker

router = APIRouter(tags=["system"])


@router.get(
    "/health",
    summary="Health check",
    description="Verifies the service is running and the database connection is alive.",
    responses={
        200: {"description": "Service healthy", "content": {"application/json": {"example": {"status": "ok"}}}},
        503: {"description": "Database unreachable"},
    },
)
async def healthcheck() -> dict:
    async with async_session_maker() as session:
        await session.execute(text("SELECT 1"))
    return {"status": "ok"}
