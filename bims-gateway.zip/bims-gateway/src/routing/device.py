from fastapi import APIRouter, Depends, Header
from sqlalchemy import select
from sqlalchemy.orm import joinedload

from core.database import CurrentAsyncSession
from depends import verify_bearer
from models.bims import BIMSDeviceRegistry
from routing.device_access import ensure_device_operational
from schemas.device import DeviceConfigResponse

router = APIRouter(prefix="/api/v1", tags=["device"], dependencies=[Depends(verify_bearer)])


@router.get(
    "/device/config",
    response_model=DeviceConfigResponse,
    summary="Morning device configuration",
    description=(
        "Returns the laboratory profile for the requesting TSD device. "
        "The device is identified by the `X-Device-Serial` header. "
        "Used by the Android app on startup to load its configuration."
    ),
    responses={
        200: {
            "description": "Lab profile for the device",
            "content": {
                "application/json": {
                    "example": {
                        "clinic_code": "CLINIC_TEST_01",
                        "lab_code": "LAB_01",
                        "barcode_regex_pattern": "^[A-Z0-9]{10,14}$",
                        "aliquots_in_set_count": 6,
                        "allowed_tubes": ["EDTA", "SST", "Citrate"],
                    }
                }
            },
        },
        401: {"description": "Missing or invalid Bearer token"},
        403: {"description": "Device serial not registered or device is inactive"},
    },
)
async def get_device_config(
    session: CurrentAsyncSession,
    x_device_serial: str = Header(..., alias="X-Device-Serial", description="TSD hardware serial number"),
) -> DeviceConfigResponse:
    result = await session.execute(
        select(BIMSDeviceRegistry)
        .options(
            joinedload(BIMSDeviceRegistry.clinic),
            joinedload(BIMSDeviceRegistry.labs_config),
        )
        .where(BIMSDeviceRegistry.device_serial == x_device_serial)
    )
    device = result.scalars().first()

    device = ensure_device_operational(device)

    return DeviceConfigResponse(
        clinic_code=device.clinic.clinic_code,
        clinic_name=device.clinic.clinic_name,
        lab_code=device.labs_config.lab_code,
        barcode_regex_pattern=device.labs_config.barcode_regex_pattern,
        cryo_barcode_regex_pattern=device.labs_config.cryo_barcode_regex_pattern,
        patient_hash_salt=device.labs_config.patient_hash_salt,
        aliquots_in_set_count=device.labs_config.aliquots_in_set_count,
        allowed_tubes=device.labs_config.allowed_tubes,
    )
