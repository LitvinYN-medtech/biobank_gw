"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-06-15
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "dict_clinics",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_code", sa.String(64), nullable=False),
        sa.Column("clinic_name", sa.String(256), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("clinic_code"),
    )

    op.create_table(
        "dict_labs_configs",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("lab_code", sa.String(64), nullable=False),
        sa.Column("barcode_regex_pattern", sa.String(512), nullable=False),
        sa.Column("aliquots_in_set_count", sa.Integer(), nullable=False),
        sa.Column("allowed_tubes", JSONB(), nullable=False, server_default=sa.text("'[]'::jsonb")),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["clinic_id"], ["dict_clinics.id"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("clinic_id", "lab_code", name="uq_labs_config_clinic_lab"),
    )

    op.create_table(
        "bims_device_registry",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("device_serial", sa.String(128), nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("labs_config_id", sa.Integer(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="true"),
        sa.Column("registered_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["clinic_id"], ["dict_clinics.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(["labs_config_id"], ["dict_labs_configs.id"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("device_serial"),
    )
    op.create_index("ix_bims_device_registry_device_serial", "bims_device_registry", ["device_serial"])

    op.create_table(
        "server_vacuum_sessions",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("session_id", sa.String(128), nullable=False),
        sa.Column("device_id", sa.Integer(), nullable=False),
        sa.Column("session_date", sa.DateTime(timezone=True), nullable=False),
        sa.Column("received_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["device_id"], ["bims_device_registry.id"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("session_id"),
    )
    op.create_index("ix_server_vacuum_sessions_session_id", "server_vacuum_sessions", ["session_id"])

    op.create_table(
        "server_cryo_aliquots",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("session_id", sa.String(128), nullable=False),
        sa.Column("aliquot_id", sa.String(128), nullable=False),
        sa.Column("tube_type", sa.String(64), nullable=True),
        sa.Column("barcode", sa.String(256), nullable=True),
        sa.Column("position", sa.Integer(), nullable=True),
        sa.Column("status", sa.String(64), nullable=True),
        sa.Column("scanned_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("lis_ancestry_payload", JSONB(), nullable=True),
        sa.Column("consent_digital_payload", JSONB(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["session_id"], ["server_vacuum_sessions.session_id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("session_id", "aliquot_id", name="uq_cryo_aliquot_session_aliquot"),
    )
    op.create_index("ix_server_cryo_aliquots_session_id", "server_cryo_aliquots", ["session_id"])

    op.create_table(
        "server_shipped_containers_log",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("session_id", sa.String(128), nullable=False),
        sa.Column("container_barcode", sa.String(256), nullable=False),
        sa.Column("shipped_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["session_id"], ["server_vacuum_sessions.session_id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_shipped_containers_session_id", "server_shipped_containers_log", ["session_id"])


def downgrade() -> None:
    op.drop_table("server_shipped_containers_log")
    op.drop_index("ix_server_cryo_aliquots_session_id")
    op.drop_table("server_cryo_aliquots")
    op.drop_index("ix_server_vacuum_sessions_session_id")
    op.drop_table("server_vacuum_sessions")
    op.drop_index("ix_bims_device_registry_device_serial")
    op.drop_table("bims_device_registry")
    op.drop_table("dict_labs_configs")
    op.drop_table("dict_clinics")
