"""add unique constraint on shipped containers session + barcode

Revision ID: 0003
Revises: 0002
Create Date: 2026-07-06
"""

from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_unique_constraint(
        "uq_shipped_container_session_barcode",
        "server_shipped_containers_log",
        ["session_id", "container_barcode"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "uq_shipped_container_session_barcode",
        "server_shipped_containers_log",
        type_="unique",
    )
