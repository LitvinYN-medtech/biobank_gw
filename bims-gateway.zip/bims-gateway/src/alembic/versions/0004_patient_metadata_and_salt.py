"""patient hash salt, cryo barcode pattern, vacuum session metadata

Revision ID: 0004
Revises: 0003
Create Date: 2026-07-06
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "dict_labs_configs",
        sa.Column("patient_hash_salt", sa.String(128), nullable=False, server_default=""),
    )
    op.add_column(
        "dict_labs_configs",
        sa.Column("cryo_barcode_regex_pattern", sa.String(512), nullable=True),
    )
    op.add_column(
        "server_vacuum_sessions",
        sa.Column("vacuum_barcode_raw", sa.String(256), nullable=True),
    )
    op.add_column(
        "server_vacuum_sessions",
        sa.Column("patient_metadata_jsonb", JSONB(), nullable=True),
    )
    op.alter_column("dict_labs_configs", "patient_hash_salt", server_default=None)

    op.execute(
        """
        UPDATE dict_labs_configs
        SET barcode_regex_pattern = '^G:(?<gender>[MF]);AGE:(?<age>\\d+);UID:(?<patientId>\\d+)$',
            patient_hash_salt = 'mgt_bims_test_salt_2026',
            cryo_barcode_regex_pattern = '^[A-Z0-9]{10,14}$'
        WHERE lab_code = 'LAB_01'
        """
    )


def downgrade() -> None:
    op.drop_column("server_vacuum_sessions", "patient_metadata_jsonb")
    op.drop_column("server_vacuum_sessions", "vacuum_barcode_raw")
    op.drop_column("dict_labs_configs", "cryo_barcode_regex_pattern")
    op.drop_column("dict_labs_configs", "patient_hash_salt")
