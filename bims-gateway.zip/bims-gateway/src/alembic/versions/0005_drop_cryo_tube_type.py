"""drop tube_type from server_cryo_aliquots

Revision ID: 0005
Revises: 0004
Create Date: 2026-07-06
"""

import sqlalchemy as sa
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.drop_column("server_cryo_aliquots", "tube_type")


def downgrade() -> None:
    op.add_column(
        "server_cryo_aliquots",
        sa.Column("tube_type", sa.String(64), nullable=True),
    )
