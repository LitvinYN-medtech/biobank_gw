"""add business audit trail table

Revision ID: 0006
Revises: 0005
Create Date: 2026-07-09
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "audit_trail_events",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("event_id", sa.String(128), nullable=False),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "received_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column("device_serial", sa.String(128), nullable=False),
        sa.Column("clinic_code", sa.String(64), nullable=True),
        sa.Column("lab_code", sa.String(64), nullable=True),
        sa.Column("session_id", sa.String(128), nullable=True),
        sa.Column("vacuum_barcode_raw", sa.String(256), nullable=True),
        sa.Column("cryo_barcode", sa.String(256), nullable=True),
        sa.Column("patient_hash", sa.String(64), nullable=True),
        sa.Column("container_id", sa.String(256), nullable=True),
        sa.Column("sync_result", sa.String(32), nullable=True),
        sa.Column("error_details", sa.Text(), nullable=True),
        sa.Column("payload", JSONB(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("event_id", name="uq_audit_trail_event_id"),
    )
    op.create_index(
        "ix_audit_trail_events_device_serial",
        "audit_trail_events",
        ["device_serial"],
    )
    op.create_index(
        "ix_audit_trail_events_occurred_at",
        "audit_trail_events",
        ["occurred_at"],
    )
    op.create_index(
        "ix_audit_trail_events_session_id",
        "audit_trail_events",
        ["session_id"],
    )
    op.create_index(
        "ix_audit_trail_events_container_id",
        "audit_trail_events",
        ["container_id"],
    )


def downgrade() -> None:
    op.drop_index("ix_audit_trail_events_container_id")
    op.drop_index("ix_audit_trail_events_session_id")
    op.drop_index("ix_audit_trail_events_occurred_at")
    op.drop_index("ix_audit_trail_events_device_serial")
    op.drop_table("audit_trail_events")
