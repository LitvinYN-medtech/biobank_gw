"""add server_audit_events table

Revision ID: 0002
Revises: 0001
Create Date: 2026-06-19
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "0002"
down_revision: Union[str, None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "server_audit_events",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("event_id", sa.String(128), nullable=False),
        sa.Column("device_serial", sa.String(128), nullable=False),
        sa.Column("patient_hash", sa.String(64), nullable=True),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("payload", JSONB(), nullable=True),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "received_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("event_id", name="uq_audit_event_id"),
    )
    op.create_index(
        "ix_server_audit_events_device_serial", "server_audit_events", ["device_serial"]
    )
    op.create_index(
        "ix_server_audit_events_occurred_at", "server_audit_events", ["occurred_at"]
    )


def downgrade() -> None:
    op.drop_index("ix_server_audit_events_occurred_at")
    op.drop_index("ix_server_audit_events_device_serial")
    op.drop_table("server_audit_events")
