from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    POSTGRES_USER: str = "bims"
    POSTGRES_PASSWORD: str = "bims"
    POSTGRES_DB: str = "bims"
    DB_HOST: str = "localhost"
    PORT_DB: str = "5432"

    BEARER_TOKEN: str = "mgt_bims_mvp_2026_token"

    @property
    def pg_url(self) -> str:
        return (
            f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@"
            f"{self.DB_HOST}:{self.PORT_DB}/{self.POSTGRES_DB}"
        )

    @property
    def pg_url_sync(self) -> str:
        return (
            f"postgresql+psycopg2://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@"
            f"{self.DB_HOST}:{self.PORT_DB}/{self.POSTGRES_DB}"
        )

    class Config:
        env_file = ".env"


def get_settings() -> Settings:
    return Settings()
