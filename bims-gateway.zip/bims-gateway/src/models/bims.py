from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from core.database import Base


class DictClinic(Base):
    __tablename__ = "dict_clinics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    clinic_name: Mapped[str] = mapped_column(String(256), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    labs_configs: Mapped[list["DictLabsConfig"]] = relationship("DictLabsConfig", back_populates="clinic")
    device_registries: Mapped[list["BIMSDeviceRegistry"]] = relationship("BIMSDeviceRegistry", back_populates="clinic")


class DictLabsConfig(Base):
    __tablename__ = "dict_labs_configs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, ForeignKey("dict_clinics.id", ondelete="RESTRICT"), nullable=False)
    lab_code: Mapped[str] = mapped_column(String(64), nullable=False)
    barcode_regex_pattern: Mapped[str] = mapped_column(String(512), nullable=False)
    cryo_barcode_regex_pattern: Mapped[str | None] = mapped_column(String(512), nullable=True)
    patient_hash_salt: Mapped[str] = mapped_column(String(128), nullable=False, server_default="")
    aliquots_in_set_count: Mapped[int] = mapped_column(Integer, nullable=False)
    allowed_tubes: Mapped[list] = mapped_column(JSONB, nullable=False, server_default=text("'[]'::jsonb"), default=list)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    clinic: Mapped["DictClinic"] = relationship("DictClinic", back_populates="labs_configs")
    device_registries: Mapped[list["BIMSDeviceRegistry"]] = relationship(
        "BIMSDeviceRegistry", back_populates="labs_config"
    )

    __table_args__ = (UniqueConstraint("clinic_id", "lab_code", name="uq_labs_config_clinic_lab"),)


class BIMSDeviceRegistry(Base):
    __tablename__ = "bims_device_registry"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    device_serial: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    clinic_id: Mapped[int] = mapped_column(Integer, ForeignKey("dict_clinics.id", ondelete="RESTRICT"), nullable=False)
    labs_config_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("dict_labs_configs.id", ondelete="RESTRICT"), nullable=False
    )
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    registered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    clinic: Mapped["DictClinic"] = relationship("DictClinic", back_populates="device_registries")
    labs_config: Mapped["DictLabsConfig"] = relationship("DictLabsConfig", back_populates="device_registries")
    vacuum_sessions: Mapped[list["ServerVacuumSession"]] = relationship(
        "ServerVacuumSession", back_populates="device"
    )

    __table_args__ = (Index("ix_bims_device_registry_device_serial", "device_serial"),)


class ServerVacuumSession(Base):
    __tablename__ = "server_vacuum_sessions"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    device_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("bims_device_registry.id", ondelete="RESTRICT"), nullable=False
    )
    session_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    vacuum_barcode_raw: Mapped[str | None] = mapped_column(String(256), nullable=True)
    patient_metadata_jsonb: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    device: Mapped["BIMSDeviceRegistry"] = relationship("BIMSDeviceRegistry", back_populates="vacuum_sessions")
    cryo_aliquots: Mapped[list["ServerCryoAliquot"]] = relationship(
        "ServerCryoAliquot", back_populates="vacuum_session"
    )

    __table_args__ = (Index("ix_server_vacuum_sessions_session_id", "session_id"),)


class ServerCryoAliquot(Base):
    __tablename__ = "server_cryo_aliquots"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(
        String(128), ForeignKey("server_vacuum_sessions.session_id", ondelete="CASCADE"), nullable=False
    )
    aliquot_id: Mapped[str] = mapped_column(String(128), nullable=False)
    barcode: Mapped[str | None] = mapped_column(String(256), nullable=True)
    position: Mapped[int | None] = mapped_column(Integer, nullable=True)
    status: Mapped[str | None] = mapped_column(String(64), nullable=True)
    scanned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    lis_ancestry_payload: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    consent_digital_payload: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    vacuum_session: Mapped["ServerVacuumSession"] = relationship(
        "ServerVacuumSession", back_populates="cryo_aliquots"
    )

    __table_args__ = (
        UniqueConstraint("session_id", "aliquot_id", name="uq_cryo_aliquot_session_aliquot"),
        Index("ix_server_cryo_aliquots_session_id", "session_id"),
    )


class ServerAuditEvent(Base):
    __tablename__ = "server_audit_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    event_id: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    device_serial: Mapped[str] = mapped_column(String(128), nullable=False)
    patient_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    payload: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    __table_args__ = (
        UniqueConstraint("event_id", name="uq_audit_event_id"),
        Index("ix_server_audit_events_device_serial", "device_serial"),
        Index("ix_server_audit_events_occurred_at", "occurred_at"),
    )


class ServerShippedContainersLog(Base):
    __tablename__ = "server_shipped_containers_log"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(
        String(128), ForeignKey("server_vacuum_sessions.session_id", ondelete="CASCADE"), nullable=False
    )
    container_barcode: Mapped[str] = mapped_column(String(256), nullable=False)
    shipped_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    __table_args__ = (
        Index("ix_shipped_containers_session_id", "session_id"),
        UniqueConstraint("session_id", "container_barcode", name="uq_shipped_container_session_barcode"),
    )
