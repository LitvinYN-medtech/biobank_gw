from fastapi import FastAPI, HTTPException
from sqlalchemy.exc import SQLAlchemyError

from configs import get_settings
from core.errors import http_exception_handler, sqlalchemy_error_handler
from routing.audit import router as audit_router
from routing.device import router as device_router
from routing.health import router as health_router
from routing.sync import router as sync_router

settings = get_settings()

app = FastAPI(
    title="BIMS Gateway",
    version="0.1.0",
    description=(
        "REST gateway between BIMS Android TSD devices and the central PostgreSQL 16 database.\n\n"
        "## Authentication\n\n"
        "All `/api/v1/*` endpoints require `Authorization: Bearer <token>` header.\n\n"
        "## Idempotency\n\n"
        "POST `/api/v1/sync/aliquots` is fully idempotent: re-sending the same "
        "`session_id` + `aliquot_id` combination never creates duplicates."
    ),
    contact={"name": "BIMS Team"},
    license_info={"name": "Proprietary"},
)

app.add_exception_handler(SQLAlchemyError, sqlalchemy_error_handler)
app.add_exception_handler(HTTPException, http_exception_handler)

app.include_router(health_router)
app.include_router(device_router)
app.include_router(sync_router)
app.include_router(audit_router)
