"""
Shared fixtures for the test suite.

nullpool_session: opt-in fixture that replaces the default pooled DB session
with NullPool so each request gets a fresh connection. Use in tests that make
multiple sequential requests within one async context (prevents asyncpg
"another operation is in progress" errors).
"""

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from app import app
from configs import get_settings
from core.database import get_async_session

settings = get_settings()


@pytest.fixture
def nullpool_session():
    """Override DB session with NullPool for full per-request connection isolation."""
    test_engine = create_async_engine(settings.pg_url, poolclass=NullPool)
    test_session_maker = async_sessionmaker(test_engine, expire_on_commit=False)

    async def _get_test_session():
        async with test_session_maker() as session:
            yield session

    app.dependency_overrides[get_async_session] = _get_test_session
    yield
    app.dependency_overrides.clear()
