"""Contract tests for POST /api/v1/sync/containers."""

import pytest
from httpx import ASGITransport, AsyncClient

from app import app

AUTH = {"Authorization": "Bearer mgt_bims_mvp_2026_token"}
VALID_DEVICE = "TSD-TEST-001"

ALIQUOTS_PAYLOAD = {
    "session_id": "SESSION-CONTAINER-001",
    "session_date": "2026-06-15T08:00:00Z",
    "device_serial": VALID_DEVICE,
    "aliquots": [
        {"aliquot_id": "ALQ-001", "barcode": "BC001", "position": 1, "status": "ok"},
    ],
}

CONTAINERS_PAYLOAD = {
    "device_serial": VALID_DEVICE,
    "container_barcode": "plt-001",
    "shipped_at": "2026-06-15T10:00:00Z",
    "session_ids": ["SESSION-CONTAINER-001"],
}


@pytest.mark.asyncio
async def test_sync_containers_201_created(nullpool_session):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        await ac.post("/api/v1/sync/aliquots", json=ALIQUOTS_PAYLOAD, headers=AUTH)
        resp = await ac.post("/api/v1/sync/containers", json=CONTAINERS_PAYLOAD, headers=AUTH)

    assert resp.status_code == 201
    data = resp.json()
    assert data["container_barcode"] == "PLT-001"
    assert data["accepted"] is True


@pytest.mark.asyncio
async def test_sync_containers_idempotent(nullpool_session):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        await ac.post("/api/v1/sync/aliquots", json=ALIQUOTS_PAYLOAD, headers=AUTH)
        r1 = await ac.post("/api/v1/sync/containers", json=CONTAINERS_PAYLOAD, headers=AUTH)
        r2 = await ac.post("/api/v1/sync/containers", json=CONTAINERS_PAYLOAD, headers=AUTH)

    assert r1.status_code == 201
    assert r2.status_code == 201
    assert r2.json()["accepted"] is True


@pytest.mark.asyncio
async def test_sync_containers_unknown_device_403(nullpool_session):
    payload = {**CONTAINERS_PAYLOAD, "device_serial": "UNKNOWN-DEVICE"}
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/sync/containers", json=payload, headers=AUTH)
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_sync_containers_401_no_token(nullpool_session):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/sync/containers", json=CONTAINERS_PAYLOAD)
    assert resp.status_code == 403
