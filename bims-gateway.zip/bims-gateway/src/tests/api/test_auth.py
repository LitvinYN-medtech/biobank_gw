import pytest
from fastapi import Depends
from fastapi.testclient import TestClient

from app import app
from depends import verify_bearer
from routing.health import router as health_router
from fastapi import APIRouter

# Protected test endpoint
_test_router = APIRouter()


@_test_router.get("/test-auth", dependencies=[Depends(verify_bearer)])
async def _protected() -> dict:
    return {"authenticated": True}


app.include_router(_test_router)

client = TestClient(app, raise_server_exceptions=True)


def test_no_token_returns_403():
    resp = client.get("/test-auth")
    assert resp.status_code == 403


def test_wrong_token_returns_401():
    resp = client.get("/test-auth", headers={"Authorization": "Bearer wrong_token"})
    assert resp.status_code == 401


def test_correct_token_returns_200():
    resp = client.get("/test-auth", headers={"Authorization": "Bearer mgt_bims_mvp_2026_token"})
    assert resp.status_code == 200
    assert resp.json() == {"authenticated": True}


def test_healthcheck_no_auth_needed():
    # healthcheck is public — no token required, but DB may not be available in unit tests
    # Just verify it's routed (status is not 404)
    resp = client.get("/health")
    assert resp.status_code != 404
