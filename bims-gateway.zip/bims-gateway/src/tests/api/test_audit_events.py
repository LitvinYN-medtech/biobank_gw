"""Contract tests for POST /api/v1/audit/events (§10, ФЗ-152)."""

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy import select

from app import app
from core.database import async_session_maker
from models.bims import AuditTrailEvent

AUTH = {"Authorization": "Bearer mgt_bims_mvp_2026_token"}
DEVICE = "TSD-TEST-001"

VALID_HASH = "a" * 64  # 64 lowercase hex chars — valid SHA-256 placeholder


def _batch(*event_ids: str) -> dict:
    """Build a batch with unique event_ids to avoid cross-test conflicts."""
    return {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": eid,
                "event_type": "scan_complete",
                "occurred_at": "2026-06-19T08:00:00Z",
                "patient_hash": VALID_HASH,
                "payload": {"tube_count": 6},
            }
            for eid in event_ids
        ],
    }


@pytest.mark.asyncio
async def test_audit_201_created(nullpool_session):
    batch = _batch("EVT-T1-A", "EVT-T1-B")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert resp.status_code == 201
    assert resp.json()["accepted"] == 2


@pytest.mark.asyncio
async def test_audit_persists_business_trail_columns(nullpool_session):
    batch = {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": "EVT-T1-COLUMNS",
                "event_type": "EV_CONTAINER_SHIPPED",
                "occurred_at": "2026-07-09T08:00:00Z",
                "patient_hash": VALID_HASH,
                "payload": {
                    "clinic_code": "CLINIC_01",
                    "lab_code": "LAB_01",
                    "session_id": "SSN001",
                    "vacuum_barcode": "VAC-001",
                    "barcode": "CRYO-001",
                    "container_barcode": "BOX-001",
                },
            }
        ],
    }

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert resp.status_code == 201

    async with async_session_maker() as session:
        event = (
            await session.execute(
                select(AuditTrailEvent).where(
                    AuditTrailEvent.event_id == "EVT-T1-COLUMNS"
                )
            )
        ).scalar_one()

    assert event.device_serial == DEVICE
    assert event.clinic_code == "CLINIC_01"
    assert event.lab_code == "LAB_01"
    assert event.session_id == "SSN001"
    assert event.vacuum_barcode_raw == "VAC-001"
    assert event.cryo_barcode == "CRYO-001"
    assert event.container_id == "BOX-001"
    assert event.patient_hash == VALID_HASH


@pytest.mark.asyncio
async def test_audit_idempotent(nullpool_session):
    """Re-sending the same batch must return 201 without error."""
    batch = _batch("EVT-T2-A", "EVT-T2-B")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        r1 = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
        r2 = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert r1.status_code == 201
    assert r2.status_code == 201
    assert r2.json()["accepted"] == 2


@pytest.mark.asyncio
async def test_audit_401_no_token(nullpool_session):
    batch = _batch("EVT-T3-A")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch)
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_audit_rejects_invalid_patient_hash(nullpool_session):
    """Plain patient ID or short hash → 422 (ФЗ-152)."""
    bad_batch = {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": "EVT-T4-BAD",
                "event_type": "scan_complete",
                "occurred_at": "2026-06-19T08:00:00Z",
                "patient_hash": "PATIENT-12345",  # not a SHA-256 hex
            }
        ],
    }
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=bad_batch, headers=AUTH)
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_audit_accepts_null_patient_hash(nullpool_session):
    """patient_hash is optional — omitting it is fine."""
    batch = {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": "EVT-T5-NOHASH",
                "event_type": "session_close",
                "occurred_at": "2026-06-19T09:00:00Z",
            }
        ],
    }
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert resp.status_code == 201


@pytest.mark.asyncio
async def test_audit_sync_failure_persists_gateway_details(nullpool_session):
    batch = {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": "EVT-T6-SYNC-FAIL",
                "event_type": "SYNC_FAILURE",
                "occurred_at": "2026-07-10T19:07:00Z",
                "session_id": "SSN-SYNC-001",
                "payload": {
                    "entity_type": "aliquots",
                    "entity_id": "SSN-SYNC-001",
                    "sync_result": "failure",
                    "api_path": "/api/v1/sync/aliquots",
                    "reason": "ошибка сервера",
                    "http_status": 500,
                    "gateway_message": "Database transaction failed and was rolled back",
                    "gateway_response_body": '{"message":"Database transaction failed and was rolled back","postgres_code":"23503"}',
                },
            }
        ],
    }

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert resp.status_code == 201

    async with async_session_maker() as session:
        event = (
            await session.execute(
                select(AuditTrailEvent).where(
                    AuditTrailEvent.event_id == "EVT-T6-SYNC-FAIL"
                )
            )
        ).scalar_one()

    assert event.session_id == "SSN-SYNC-001"
    assert event.sync_result == "FAILURE"
    assert "ошибка сервера" in (event.error_details or "")
    assert "gateway_message: Database transaction failed" in (event.error_details or "")
    assert "postgres_code" in (event.error_details or "")
    assert event.payload is not None
    assert event.payload["api_path"] == "/api/v1/sync/aliquots"


@pytest.mark.asyncio
async def test_audit_sync_success_top_level_session_id(nullpool_session):
    batch = {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": "EVT-T7-SYNC-OK",
                "event_type": "SYNC_SUCCESS",
                "occurred_at": "2026-07-10T19:08:00Z",
                "session_id": "SSN-SYNC-002",
                "payload": {
                    "entity_type": "aliquots",
                    "entity_id": "SSN-SYNC-002",
                    "sync_result": "success",
                    "api_path": "/api/v1/sync/aliquots",
                    "accepted": 6,
                },
            }
        ],
    }

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert resp.status_code == 201

    async with async_session_maker() as session:
        event = (
            await session.execute(
                select(AuditTrailEvent).where(
                    AuditTrailEvent.event_id == "EVT-T7-SYNC-OK"
                )
            )
        ).scalar_one()

    assert event.session_id == "SSN-SYNC-002"
    assert event.sync_result == "SUCCESS"
    assert event.error_details is None
