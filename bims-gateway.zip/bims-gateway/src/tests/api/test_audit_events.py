"""Contract tests for POST /api/v1/audit/events (§10, ФЗ-152)."""

import pytest
from httpx import ASGITransport, AsyncClient

from app import app

AUTH = {"Authorization": "Bearer mgt_bims_mvp_2026_token"}
DEVICE = "TSD-TEST-001"

VALID_HASH = "a" * 64  # 64 lowercase hex chars — valid SHA-256 placeholder


def _batch(*event_ids: str) -> dict:
    """Build a batch with unique event_ids to avoid cross-test conflicts."""
    return {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": eid,
                "event_type": "scan_complete",
                "occurred_at": "2026-06-19T08:00:00Z",
                "patient_hash": VALID_HASH,
                "payload": {"tube_count": 6},
            }
            for eid in event_ids
        ],
    }


@pytest.mark.asyncio
async def test_audit_201_created(nullpool_session):
    batch = _batch("EVT-T1-A", "EVT-T1-B")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert resp.status_code == 201
    assert resp.json()["accepted"] == 2


@pytest.mark.asyncio
async def test_audit_idempotent(nullpool_session):
    """Re-sending the same batch must return 201 without error."""
    batch = _batch("EVT-T2-A", "EVT-T2-B")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        r1 = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
        r2 = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert r1.status_code == 201
    assert r2.status_code == 201
    assert r2.json()["accepted"] == 2


@pytest.mark.asyncio
async def test_audit_401_no_token(nullpool_session):
    batch = _batch("EVT-T3-A")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch)
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_audit_rejects_invalid_patient_hash(nullpool_session):
    """Plain patient ID or short hash → 422 (ФЗ-152)."""
    bad_batch = {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": "EVT-T4-BAD",
                "event_type": "scan_complete",
                "occurred_at": "2026-06-19T08:00:00Z",
                "patient_hash": "PATIENT-12345",  # not a SHA-256 hex
            }
        ],
    }
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=bad_batch, headers=AUTH)
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_audit_accepts_null_patient_hash(nullpool_session):
    """patient_hash is optional — omitting it is fine."""
    batch = {
        "device_serial": DEVICE,
        "events": [
            {
                "event_id": "EVT-T5-NOHASH",
                "event_type": "session_close",
                "occurred_at": "2026-06-19T09:00:00Z",
            }
        ],
    }
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        resp = await ac.post("/api/v1/audit/events", json=batch, headers=AUTH)
    assert resp.status_code == 201
