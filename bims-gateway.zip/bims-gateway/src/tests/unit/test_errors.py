"""Unit tests for structured gateway error responses."""

from core.errors import gateway_error_body, postgres_error_details


class _FakeDiag:
    message_primary = "insert or update on table violates foreign key constraint"
    message_detail = 'Key (session_id)=(MISSING) is not present in table "server_vacuum_sessions".'
    constraint_name = "server_cryo_aliquots_session_id_fkey"
    table_name = "server_cryo_aliquots"
    column_name = "session_id"


class _FakeOrig:
    sqlstate = "23503"
    diag = _FakeDiag()

    def __str__(self) -> str:
        return self.diag.message_primary


class _FakeSqlalchemyError(Exception):
    orig = _FakeOrig()


def test_postgres_error_details_extracts_diagnostics():
    details = postgres_error_details(_FakeSqlalchemyError())

    assert details["postgres_code"] == "23503"
    assert "foreign key constraint" in details["postgres_message"]
    assert details["postgres_constraint"] == "server_cryo_aliquots_session_id_fkey"
    assert details["postgres_table"] == "server_cryo_aliquots"


def test_gateway_error_body_includes_message_for_mobile_client():
    body = gateway_error_body(
        "Database transaction failed and was rolled back",
        status_code=500,
        extra={"postgres_code": "23503"},
    )

    assert body["message"] == "Database transaction failed and was rolled back"
    assert body["http_status"] == 500
    assert body["postgres_code"] == "23503"
