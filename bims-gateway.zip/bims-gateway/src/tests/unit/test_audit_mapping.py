"""Unit tests for audit trail column mapping."""

from datetime import datetime

from routing.audit_mapping import (
    resolve_container_id,
    resolve_error_details,
    resolve_session_id,
    resolve_sync_result,
)
from schemas.audit import AuditEvent


def _event(**kwargs) -> AuditEvent:
    defaults = {
        "event_id": "EVT-1",
        "event_type": "SYNC_FAILURE",
        "occurred_at": datetime(2026, 7, 10, 19, 7),
    }
    defaults.update(kwargs)
    return AuditEvent(**defaults)


def test_resolve_session_id_prefers_top_level_field():
    event = _event(session_id="TOP-LEVEL", payload={"session_id": "PAYLOAD"})
    assert resolve_session_id(event) == "TOP-LEVEL"


def test_resolve_session_id_from_aliquots_entity_id():
    event = _event(
        payload={
            "entity_type": "aliquots",
            "entity_id": "SSN-123",
        }
    )
    assert resolve_session_id(event) == "SSN-123"


def test_resolve_container_id_from_ship_payload_only():
    assert resolve_container_id({"container_barcode": "BOX-001"}) == "BOX-001"
    # SYNC_SUCCESS must not put entity_id into container_id
    assert (
        resolve_container_id({"entity_type": "container", "entity_id": "SSN-123"})
        is None
    )


def test_resolve_sync_result_normalizes_mobile_values():
    assert resolve_sync_result("SYNC_SUCCESS", {"sync_result": "success"}) == "SUCCESS"
    assert resolve_sync_result("SYNC_FAILURE", {"sync_result": "failure"}) == "FAILURE"


def test_resolve_error_details_includes_gateway_fields():
    details = resolve_error_details(
        {
            "reason": "ошибка сервера",
            "api_path": "/api/v1/sync/aliquots",
            "http_status": 500,
            "gateway_message": "Database transaction failed and was rolled back",
            "gateway_response_body": '{"postgres_code":"23503"}',
        }
    )

    assert "ошибка сервера" in details
    assert "api_path: /api/v1/sync/aliquots" in details
    assert "gateway_message:" in details
    assert "gateway_response_body:" in details
