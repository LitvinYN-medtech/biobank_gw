# BIMS Gateway

REST sync gateway between BIMS Android TSD devices and a central PostgreSQL 16 database.

## Quick start

```bash
cp .env.example .env   # fill in passwords
make setup             # start DB + app, run migrations, seed test data
make check             # smoke-test health + device config
```

API docs: `http://localhost:8000/docs`

## Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/health` | — | DB connectivity check |
| GET | `/api/v1/device/config` | Bearer | Morning lab profile for a TSD device |
| POST | `/api/v1/sync/aliquots` | Bearer | Transactional batch aliquot sync |

## Key properties

- **Single-transaction sync** — any failure triggers full ROLLBACK
- **Idempotent** — re-sending the same session/aliquot is safe, no duplicates created
- **Static Bearer auth** — token loaded from `BEARER_TOKEN` env var (never hardcoded)

## Documentation

| Document | Description |
|---|---|
| [`docs/ddl.sql`](docs/ddl.sql) | Standalone DDL for all 6 tables |
| [`docs/openapi.json`](docs/openapi.json) | Exported OpenAPI schema |
| [`docs/deployment-vps.md`](docs/deployment-vps.md) | VPS deployment guide |
| [`docs/tsd-setup.md`](docs/tsd-setup.md) | Android TSD device setup |
| [`docs/delivery-checklist.md`](docs/delivery-checklist.md) | Final acceptance checklist |

## Development

```bash
make test          # run pytest suite
make export-openapi  # regenerate docs/openapi.json
make downgrade     # roll back one migration
make logs          # tail app + db logs
```
