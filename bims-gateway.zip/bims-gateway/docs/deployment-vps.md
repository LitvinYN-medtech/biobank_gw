# BIMS Gateway — VPS Deployment Guide

## Prerequisites

- Ubuntu 22.04 LTS (or similar) VPS with at least 1 vCPU / 1 GB RAM
- Docker 24+ and Docker Compose v2 installed
- Ports 80/443 (or 8000) open in the firewall
- Git installed

## 1. Clone the repository

```bash
git clone https://git.purpleplane-it.com/bims/bims-gateway.git
cd bims-gateway
```

## 2. Configure environment

```bash
cp .env.example .env
nano .env
```

Set the following values:

| Variable | Description | Example |
|---|---|---|
| `POSTGRES_USER` | DB username | `bims` |
| `POSTGRES_PASSWORD` | DB password (use a strong password) | `s3cr3t` |
| `POSTGRES_DB` | Database name | `bims` |
| `DB_HOST` | DB hostname (use `db` when running via docker-compose) | `db` |
| `PORT_DB` | PostgreSQL port | `5432` |
| `BEARER_TOKEN` | Static API token for TSD devices | `mgt_bims_mvp_2026_token` |

## 3. Start the stack

```bash
docker compose up -d --build
```

This starts:
- `bims_db` — PostgreSQL 16
- `bims_gateway` — FastAPI app on port 8000

## 4. Run database migrations

```bash
docker compose exec app alembic -c src/alembic.ini upgrade head
```

## 5. Seed reference data (first time only)

```bash
docker compose exec app python src/seed.py
```

## 6. Verify the service

```bash
curl http://localhost:8000/health
# Expected: {"status": "ok"}
```

```bash
curl -H "Authorization: Bearer mgt_bims_mvp_2026_token" \
     -H "X-Device-Serial: TSD-TEST-001" \
     http://localhost:8000/api/v1/device/config
```

## 7. View API documentation

Open in browser: `http://<your-server-ip>:8000/docs`

## 8. Updating the service

```bash
git pull
docker compose up -d --build
docker compose exec app alembic -c src/alembic.ini upgrade head
```

## 9. Rollback migrations

```bash
docker compose exec app alembic -c src/alembic.ini downgrade -1
```

## Logs

```bash
docker compose logs -f app
docker compose logs -f db
```
