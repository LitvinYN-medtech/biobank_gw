# BIMS Android App — TSD Device Setup Guide

## Supported devices

Android 8.0+ handheld barcode scanner / TSD (warehouse terminal).

## 1. Enable installation from unknown sources

On the TSD device:

1. Go to **Settings → Security** (exact path may vary by manufacturer)
2. Enable **"Install unknown apps"** or **"Unknown sources"**

## 2. Transfer the APK

Choose one method:

**Option A — USB cable:**
```
1. Connect TSD to PC via USB
2. Select "File Transfer" mode on the device
3. Copy bims-mobile.apk to the device storage (e.g. /sdcard/Download/)
```

**Option B — ADB (recommended for batch deployment):**
```bash
adb install bims-mobile.apk
```

**Option C — Internal network share / HTTP server:**
```bash
# On PC:
python3 -m http.server 8080
# On TSD browser: navigate to http://<PC-IP>:8080/bims-mobile.apk and download
```

## 3. Install the APK

1. Open the **Files** app on the TSD
2. Navigate to the folder where you copied the APK
3. Tap `bims-mobile.apk` and confirm installation

## 4. Configure the app

On first launch the app asks for server settings:

| Field | Value |
|---|---|
| **Server URL** | `http://<VPS-IP>:8000` |
| **Bearer token** | `mgt_bims_mvp_2026_token` |
| **Device serial** | (pre-flashed on device, read from hardware info) |

> The device serial must be pre-registered in `bims_device_registry` on the server (see seed data or admin panel). An unregistered serial returns **403 Forbidden**.

## 5. Morning startup sequence

1. Power on TSD
2. Open **BIMS** app
3. App calls `GET /api/v1/device/config` → downloads barcode regex and tube config
4. Device is ready for scanning

## 6. End-of-shift sync

1. Tap **Sync** in the app
2. App calls `POST /api/v1/sync/aliquots` with all scanned records
3. Confirmation screen shows accepted count
4. Re-sync is safe — duplicate records are ignored automatically

## 7. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| 403 on config load | Device serial not registered | Register serial in `bims_device_registry` via seed or DB admin |
| 401 on any request | Wrong bearer token in app settings | Check token in app config |
| Network error | Wrong server URL or VPS unreachable | Check VPS firewall, verify URL |
| APK won't install | "Unknown sources" disabled | Enable in Android Security settings |
