# BIMS Gateway — Final Delivery Checklist (SRS §12)

## Delivery package contents

| # | Artefact | Location | Status |
|---|---|---|---|
| 1 | Gateway source code | `src/` | ✅ |
| 2 | DDL script | `docs/ddl.sql` | ✅ |
| 3 | Alembic migrations | `src/alembic/versions/` | ✅ |
| 4 | Seed data script | `src/seed.py` | ✅ |
| 5 | OpenAPI / Swagger spec | `docs/openapi.json` (interactive at `/docs`) | ✅ |
| 6 | VPS deployment instruction | `docs/deployment-vps.md` | ✅ |
| 7 | TSD device setup instruction | `docs/tsd-setup.md` | ✅ |
| 8 | Android APK + mobile sources | supplied separately by mobile team | ⬜ |
| 9 | Acceptance act | to be signed after UAT | ⬜ |

## Results of works — acceptance criteria (SRS §12)

| # | Criterion | Verified |
|---|---|---|
| 1 | DDL applies to a clean PostgreSQL 16 DB without errors | ✅ (`alembic upgrade head`) |
| 2 | `alembic downgrade` cleanly removes the schema | ✅ |
| 3 | `GET /health` returns 200 | ✅ |
| 4 | Request without / with wrong token → 401/403 | ✅ |
| 5 | `GET /api/v1/device/config` returns correct lab profile for registered device | ✅ |
| 6 | `GET /api/v1/device/config` returns 403 for unknown/inactive device | ✅ |
| 7 | `POST /api/v1/sync/aliquots` persists a batch in a single transaction | ✅ |
| 8 | `POST /api/v1/sync/aliquots` — partial failure causes full ROLLBACK | ✅ |
| 9 | Re-sending the same payload creates no duplicate rows | ✅ |

## How to verify from scratch

```bash
# 1. Clone and configure
git clone https://git.purpleplane-it.com/bims/bims-gateway.git
cd bims-gateway
cp .env.example .env   # edit passwords as needed

# 2. Start stack + apply migrations + seed
make setup

# 3. Run all checks
make check

# 4. Open Swagger UI
open http://localhost:8000/docs
```

See `docs/deployment-vps.md` for full VPS instructions.
