-- BIMS Gateway — Central Schema DDL (SRS v3.0)
-- PostgreSQL 16

CREATE TABLE IF NOT EXISTS dict_clinics (
    id           SERIAL PRIMARY KEY,
    clinic_code  VARCHAR(64)  NOT NULL UNIQUE,
    clinic_name  VARCHAR(256) NOT NULL,
    is_active    BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS dict_labs_configs (
    id                      SERIAL PRIMARY KEY,
    clinic_id               INTEGER      NOT NULL REFERENCES dict_clinics(id) ON DELETE RESTRICT,
    lab_code                VARCHAR(64)  NOT NULL,
    barcode_regex_pattern   VARCHAR(512) NOT NULL,
    aliquots_in_set_count   INTEGER      NOT NULL,
    allowed_tubes           JSONB        NOT NULL DEFAULT '[]',
    is_active               BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_labs_config_clinic_lab UNIQUE (clinic_id, lab_code)
);

CREATE TABLE IF NOT EXISTS bims_device_registry (
    id              SERIAL PRIMARY KEY,
    device_serial   VARCHAR(128) NOT NULL UNIQUE,
    clinic_id       INTEGER      NOT NULL REFERENCES dict_clinics(id) ON DELETE RESTRICT,
    labs_config_id  INTEGER      NOT NULL REFERENCES dict_labs_configs(id) ON DELETE RESTRICT,
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    registered_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_bims_device_registry_device_serial ON bims_device_registry(device_serial);

CREATE TABLE IF NOT EXISTS server_vacuum_sessions (
    id           BIGSERIAL PRIMARY KEY,
    session_id   VARCHAR(128) NOT NULL UNIQUE,
    device_id    INTEGER      NOT NULL REFERENCES bims_device_registry(id) ON DELETE RESTRICT,
    session_date TIMESTAMPTZ  NOT NULL,
    received_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_server_vacuum_sessions_session_id ON server_vacuum_sessions(session_id);

CREATE TABLE IF NOT EXISTS server_cryo_aliquots (
    id                       BIGSERIAL PRIMARY KEY,
    session_id               VARCHAR(128) NOT NULL REFERENCES server_vacuum_sessions(session_id) ON DELETE CASCADE,
    aliquot_id               VARCHAR(128) NOT NULL,
    tube_type                VARCHAR(64),
    barcode                  VARCHAR(256),
    position                 INTEGER,
    status                   VARCHAR(64),
    scanned_at               TIMESTAMPTZ,
    lis_ancestry_payload     JSONB,
    consent_digital_payload  JSONB,
    created_at               TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_cryo_aliquot_session_aliquot UNIQUE (session_id, aliquot_id)
);

CREATE INDEX IF NOT EXISTS ix_server_cryo_aliquots_session_id ON server_cryo_aliquots(session_id);

CREATE TABLE IF NOT EXISTS server_shipped_containers_log (
    id                 BIGSERIAL PRIMARY KEY,
    session_id         VARCHAR(128) NOT NULL REFERENCES server_vacuum_sessions(session_id) ON DELETE CASCADE,
    container_barcode  VARCHAR(256) NOT NULL,
    shipped_at         TIMESTAMPTZ  NOT NULL,
    notes              TEXT,
    created_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_shipped_containers_session_id ON server_shipped_containers_log(session_id);
