# Patient hash salt and Audit Trail

## Patient hash salt

The salt is configured per laboratory in
`dict_labs_configs.patient_hash_salt`. The device receives it from
`GET /api/v1/device/config` as `patient_hash_salt`.

On the TSD, `bims-mobile` stores the downloaded value in the encrypted
SQLCipher database, table `device_configs`, column `patient_hash_salt`.
The encryption key is stored separately in Android secure storage. The salt is
used only for local SHA-256 de-identification and is never written to audit
payloads.

Production salts must be generated outside source control and loaded through
deployment configuration or a protected administration process. The value
`mgt_bims_test_salt_2026` is test/seed data only.

## Audit Trail

`audit_trail_events` is the business Audit Trail required by section 10 of the
specification. It stores pre-analytical milestones and synchronization
outcomes with explicit device, clinic, laboratory, sample, container, patient
hash, and error fields.

`server_audit_events` is reserved for technical application events and must
not be used as the BIMS business Audit Trail.
