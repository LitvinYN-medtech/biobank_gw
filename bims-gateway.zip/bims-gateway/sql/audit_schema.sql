-- Technical application events. This is not the regulated business Audit Trail.
-- Managed by Alembic migration 0002_add_audit_events.py.
-- This file is a reference copy for DBA review.

CREATE TABLE IF NOT EXISTS server_audit_events (
    id           BIGSERIAL PRIMARY KEY,
    event_id     VARCHAR(128) NOT NULL,
    device_serial VARCHAR(128) NOT NULL,
    patient_hash VARCHAR(64)  NULL,        -- SHA-256 hex only (ФЗ-152); NULL when not applicable
    event_type   VARCHAR(64)  NOT NULL,
    payload      JSONB        NULL,
    occurred_at  TIMESTAMPTZ  NOT NULL,
    received_at  TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT uq_audit_event_id UNIQUE (event_id)
);

CREATE INDEX IF NOT EXISTS ix_server_audit_events_device_serial ON server_audit_events (device_serial);
CREATE INDEX IF NOT EXISTS ix_server_audit_events_occurred_at   ON server_audit_events (occurred_at);

COMMENT ON COLUMN server_audit_events.patient_hash IS
    'SHA-256 hex digest of the patient identifier (ФЗ-152). Plain IDs are never stored.';

-- §10: BIMS business Audit Trail.
-- Managed by Alembic migration 0006_add_audit_trail_events.py.

CREATE TABLE IF NOT EXISTS audit_trail_events (
    id                   BIGSERIAL PRIMARY KEY,
    event_id             VARCHAR(128) NOT NULL,
    event_type           VARCHAR(64)  NOT NULL,
    occurred_at          TIMESTAMPTZ  NOT NULL,
    received_at          TIMESTAMPTZ  NOT NULL DEFAULT now(),
    device_serial        VARCHAR(128) NOT NULL,
    clinic_code          VARCHAR(64),
    lab_code             VARCHAR(64),
    session_id           VARCHAR(128),
    vacuum_barcode_raw   VARCHAR(256),
    cryo_barcode         VARCHAR(256),
    patient_hash         VARCHAR(64),
    container_id         VARCHAR(256),
    sync_result          VARCHAR(32),
    error_details        TEXT,
    payload              JSONB,
    CONSTRAINT uq_audit_trail_event_id UNIQUE (event_id)
);

CREATE INDEX IF NOT EXISTS ix_audit_trail_events_device_serial
    ON audit_trail_events (device_serial);
CREATE INDEX IF NOT EXISTS ix_audit_trail_events_occurred_at
    ON audit_trail_events (occurred_at);
CREATE INDEX IF NOT EXISTS ix_audit_trail_events_session_id
    ON audit_trail_events (session_id);
CREATE INDEX IF NOT EXISTS ix_audit_trail_events_container_id
    ON audit_trail_events (container_id);
